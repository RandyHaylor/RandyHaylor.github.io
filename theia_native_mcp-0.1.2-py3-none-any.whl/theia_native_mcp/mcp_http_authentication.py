"""The Streamable HTTP client authentication: a bearer token checked against a fixed secret.

The fixed secret (from ``THEIA_MCP_HTTP_SECRET``) is custom; the check runs through the MCP
Python SDK's ``TokenVerifier``
(https://py.sdk.modelcontextprotocol.io/v2/run/authorization). The ``Authorization: Bearer``
header is RFC 6750 (https://datatracker.ietf.org/doc/html/rfc6750). No Protected Resource
Metadata is advertised: the auth settings carry no ``resource_server_url``, so the MCP Python
SDK serves no metadata route and names none in its 401 ``WWW-Authenticate`` header.
"""

from __future__ import annotations

import hmac

from mcp.server.auth.provider import AccessToken, TokenVerifier
from mcp.server.auth.settings import AuthSettings
from pydantic import AnyHttpUrl

AUTHENTICATED_HTTP_CLIENT_ID = "theia_native_mcp_http_client"


class FixedSecretTokenVerifier(TokenVerifier):
    """Accepts exactly one bearer token: the fixed secret."""

    def __init__(self, http_secret: str) -> None:
        self._http_secret = http_secret

    async def verify_token(self, token: str) -> AccessToken | None:
        if not hmac.compare_digest(token.encode("utf-8"), self._http_secret.encode("utf-8")):
            return None
        return AccessToken(token=token, client_id=AUTHENTICATED_HTTP_CLIENT_ID, scopes=[])


def fixed_secret_auth_settings(mcp_server_url: str) -> AuthSettings:
    """The MCP Python SDK's auth settings for the fixed-secret check.

    ``issuer_url`` is a required field of ``AuthSettings``; this server issues nothing and
    advertises no authorization server, so it is set to the MCP server's own URL.
    ``resource_server_url`` is left unset so no Protected Resource Metadata is published.
    """
    return AuthSettings(issuer_url=AnyHttpUrl(mcp_server_url), resource_server_url=None)
