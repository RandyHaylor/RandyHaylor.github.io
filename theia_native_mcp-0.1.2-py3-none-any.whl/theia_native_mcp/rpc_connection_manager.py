"""The MCP server's RPC client for SDK endpoints: connections, ``rpc_session``, discovery,
commands, subscription streams and automatic resume.

This module holds all of the MCP server's JSON-RPC knowledge: request ids, the
``Authorization`` and ``Theia-Rpc-Session-Id`` headers and the SDK endpoint's wire protocol.
``HttpSseClient`` carries whatever body and headers it is given.
"""

from __future__ import annotations

import asyncio
import difflib
import importlib.metadata
import itertools
import ssl
import time
from collections.abc import Sequence
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any, Protocol

import httpx2

from theia_native_mcp.http_sse_client import (
    MULTIPART_MIXED_CONTENT_TYPE,
    SDK_RPC_TLS_DIRECTORY_ENVIRONMENT_VARIABLE,
    HttpReply,
    HttpSseClient,
    HttpSseStream,
    ReplyFile,
    SseStreamEndReason,
    default_sdk_rpc_server_certificate_path,
    pinned_certificate_ssl_context,
    reply_files,
)
from theia_native_mcp.json_codec import JsonCodec, JsonCodecError
from theia_native_mcp.sdk_event_buffer import BufferedEvent, SdkEventBuffer

MCP_CLIENT_NAME = "theia_native_mcp"

JSON_CONTENT_TYPE = "application/json"
# https://datatracker.ietf.org/doc/html/draft-inadarei-api-health-check-06
HEALTH_ENDPOINT_PATH = "/health"
RPC_SESSION_ID_HEADER = "Theia-Rpc-Session-Id"
RPC_SESSION_ID_REPLY_HEADER = RPC_SESSION_ID_HEADER.lower()
OPENRPC_EVENTS_FIELD = "x-events"
OPENRPC_SDK_VERSION_FIELD = "x-theia-sdk-version"

HTTP_STATUS_OK = 200
HTTP_STATUS_RPC_SESSION_NOT_FOUND = 404

DEFAULT_DROP_DETECTION_TIMEOUT_SECONDS = 45.0
HEALTH_CHECK_TIMEOUT_SECONDS = 3.0
DEFAULT_RESUME_BACKOFF_SECONDS: tuple[float, ...] = (1.0, 2.0, 4.0)

RECONNECT_FAILED_REASON = "reconnect failed, stream terminated"

_rpc_connection_numbers = itertools.count(1)


def _next_rpc_connection_id() -> str:
    return f"conn-{next(_rpc_connection_numbers)}"


class ConfiguredSdkEndpoint(Protocol):
    """An SDK endpoint from the MCP server's settings. ``certificate_path``: that SDK's RPC
    certificate; None: the certificate of the SDK on this machine."""

    name: str
    url: str
    token: str | None
    certificate_path: Path | None


class LocalSdkEndpoint(Protocol):
    """The SDK endpoint tried when ``open_rpc_connection`` is given no endpoint.
    ``certificate_path``: its RPC certificate; None: the default certificate path."""

    address: str
    port: int
    port_step: int
    port_attempts: int
    token: str | None
    certificate_path: Path | None


def _local_sdk_endpoint_candidate_urls(local_sdk_endpoint: LocalSdkEndpoint) -> list[str]:
    """``https://<address>:<port>/v1`` for each candidate port, by the SDK's port rule
    (design reference: SDK config file): ``port`` first, then each previous candidate plus
    ``port_step``, stopping at the first port outside 1-65535 as the SDK does."""
    address = local_sdk_endpoint.address
    url_host = f"[{address}]" if ":" in address else address
    candidate_urls = []
    for attempt in range(local_sdk_endpoint.port_attempts):
        port = local_sdk_endpoint.port + attempt * local_sdk_endpoint.port_step
        if not 1 <= port <= 65535:
            break
        candidate_urls.append(f"https://{url_host}:{port}/v1")
    return candidate_urls


_WAYS_TO_PROVIDE_THE_CERTIFICATE = (
    "connect's certificate argument, the endpoint's \"certificate\" setting, or "
    f"{SDK_RPC_TLS_DIRECTORY_ENVIRONMENT_VARIABLE} (the folder the SDK on this machine uses)"
)


def _pinned_certificate_ssl_context_from_file(
    certificate_path: Path | None,
) -> ssl.SSLContext | RpcConnectionFailed:
    """An SSL context trusting exactly the certificate at ``certificate_path``, read now: the
    SDK may write it after the MCP server starts. None: no folder to read it from."""
    if certificate_path is None:
        return RpcConnectionFailed(
            "no folder for the SDK RPC certificate (no home folder). Provide the certificate with "
            f"{_WAYS_TO_PROVIDE_THE_CERTIFICATE}.",
            certificate_problem=True,
        )
    try:
        certificate_pem = certificate_path.read_text(encoding="utf-8")
    except OSError:
        return RpcConnectionFailed(
            f"no SDK RPC certificate at {certificate_path}. The SDK writes its certificate when its "
            'RPC server first starts, and logs its path ("SDK RPC control server certificate: '
            f'<path>"). Provide it with {_WAYS_TO_PROVIDE_THE_CERTIFICATE}.',
            certificate_problem=True,
        )
    try:
        return pinned_certificate_ssl_context(certificate_pem)
    except (ssl.SSLError, ValueError) as error:
        return RpcConnectionFailed(
            f"the SDK RPC certificate at {certificate_path} could not be used: {error}",
            certificate_problem=True,
        )


def _is_certificate_verification_failure(error: BaseException) -> bool:
    """Whether ``error``, or an exception it was raised from, is a failed certificate check."""
    seen: set[int] = set()
    current: BaseException | None = error
    while current is not None and id(current) not in seen:
        if isinstance(current, ssl.SSLCertVerificationError):
            return True
        seen.add(id(current))
        current = current.__cause__ or current.__context__
    return False


def _certificate_mismatch(endpoint_url: str, certificate_path: Path | None) -> RpcConnectionFailed:
    return RpcConnectionFailed(
        f"the SDK at {endpoint_url} presented a different certificate than {certificate_path}; "
        "nothing was sent. If that SDK keeps its certificate elsewhere (THEIA_RPC_TLS_DIR on its "
        "host, a pair placed there, or another machine), pass that certificate's path with "
        "connect's certificate argument or the endpoint's \"certificate\" setting.",
        certificate_problem=True,
    )


class RpcConnectionState(Enum):
    OPEN = "open"
    RPC_SESSION_ENDED = "rpc_session ended"
    CONNECTION_LOST = "connection lost"


class UnknownRpcConnectionError(KeyError):
    """Raised for an ``rpc_connection_id`` that is not an open connection."""


# --- Outcomes of a request to an SDK endpoint --------------------------------------------------


@dataclass(frozen=True)
class RpcResponseReceived:
    """A single JSON-RPC response, as the SDK sent it (a result or a JSON-RPC error)."""

    json_rpc_response: dict[str, Any]


@dataclass(frozen=True)
class RpcSubscriptionStarted:
    """A subscription stream was opened and is now held; its events go to the event buffer."""

    subscription_id: str | int


@dataclass(frozen=True)
class RpcFilesReceived:
    """A reply of files (``multipart/mixed``), each named relative to the receiver's folder."""

    files: list[ReplyFile]


@dataclass(frozen=True)
class RpcHttpStatusReply:
    """An HTTP reply other than 200: 401 (token rejected) or 404 (``rpc_session`` ended)."""

    status: int
    body_text: str


@dataclass(frozen=True)
class RpcConnectionFailed:
    """The endpoint could not be reached, or its reply was not what the protocol says.
    ``certificate_problem``: the SDK's certificate was missing, unusable or not the one the
    endpoint presented."""

    reason: str
    certificate_problem: bool = False


RpcCommandOutcome = (
    RpcResponseReceived | RpcSubscriptionStarted | RpcFilesReceived | RpcHttpStatusReply | RpcConnectionFailed
)


@dataclass(frozen=True)
class RpcMethodSummary:
    name: str
    kind: str  # "method" or "event"
    summary: str


@dataclass(frozen=True)
class RpcConnectionOpened:
    rpc_connection_id: str
    sdk_version: str | None
    methods: list[RpcMethodSummary]


RpcConnectionOpenOutcome = RpcConnectionOpened | RpcResponseReceived | RpcHttpStatusReply | RpcConnectionFailed


@dataclass(frozen=True)
class RpcMethodDescription:
    """A method's or event's entry in the SDK's OpenRPC document, with its ``$ref``s resolved."""

    name: str
    kind: str  # "method" or "event"
    description: dict[str, Any]


@dataclass(frozen=True)
class RpcMethodNotFound:
    name: str
    suggestions: list[str]


@dataclass(frozen=True)
class RpcConnectionSummary:
    rpc_connection_id: str
    endpoint_url: str
    state: RpcConnectionState
    state_reason: str | None
    sdk_version: str | None
    subscription_ids: list[str | int]


# --- Connection state --------------------------------------------------------------------------


@dataclass(eq=False)
class _HeldSubscription:
    subscription_id: str | int
    event_name: str
    current_stream: HttpSseStream | None = None
    last_sdk_event_id: int = 0
    stop_requested: bool = False
    holding_task: asyncio.Task[None] | None = None


@dataclass(eq=False)
class _RpcConnection:
    rpc_connection_id: str
    endpoint_url: str
    token: str | None
    ssl_context: ssl.SSLContext
    certificate_path: Path | None = None
    rpc_session_id: str | None = None
    state: RpcConnectionState = RpcConnectionState.OPEN
    state_reason: str | None = None
    openrpc_document: dict[str, Any] = field(default_factory=dict)
    last_request_id: int = 0
    held_subscriptions: dict[str | int, _HeldSubscription] = field(default_factory=dict)

    def next_request_id(self) -> int:
        self.last_request_id += 1
        return self.last_request_id

    @property
    def sdk_version(self) -> str | None:
        return self.openrpc_document.get(OPENRPC_SDK_VERSION_FIELD)


def _schema_at_reference(openrpc_document: dict[str, Any], reference: str) -> Any | None:
    """The value a local ``#/...`` reference points to in the document, or None."""
    if not reference.startswith("#"):
        return None
    referenced_value: Any = openrpc_document
    for path_token in reference[1:].split("/")[1:]:
        path_token = path_token.replace("~1", "/").replace("~0", "~")
        if not isinstance(referenced_value, dict) or path_token not in referenced_value:
            return None
        referenced_value = referenced_value[path_token]
    return referenced_value


def _with_references_resolved(
    value: Any, openrpc_document: dict[str, Any], references_being_resolved: tuple[str, ...] = ()
) -> Any:
    """``value`` with every ``$ref`` replaced, recursively, by the schema it points to
    (OpenRPC Reference Object, https://spec.open-rpc.org/#reference-object). A reference that
    cannot be found, or that refers back to one being resolved, is left as it is."""
    if isinstance(value, list):
        return [_with_references_resolved(item, openrpc_document, references_being_resolved) for item in value]
    if not isinstance(value, dict):
        return value
    reference = value.get("$ref")
    if isinstance(reference, str) and reference not in references_being_resolved:
        referenced_schema = _schema_at_reference(openrpc_document, reference)
        if referenced_schema is not None:
            return _with_references_resolved(
                referenced_schema, openrpc_document, references_being_resolved + (reference,)
            )
    return {
        key: _with_references_resolved(item, openrpc_document, references_being_resolved)
        for key, item in value.items()
    }


def _first_line(text: Any) -> str:
    if not isinstance(text, str):
        return ""
    return text.strip().splitlines()[0] if text.strip() else ""


class RpcConnectionManager:
    """RPC connections to SDK endpoints, by ``rpc_connection_id``."""

    def __init__(
        self,
        http_sse_client: HttpSseClient,
        json_codec: JsonCodec,
        sdk_event_buffer: SdkEventBuffer,
        configured_endpoints: Sequence[ConfiguredSdkEndpoint] = (),
        local_sdk_endpoint: LocalSdkEndpoint | None = None,
        default_token: str | None = None,
        drop_detection_timeout_seconds: float = DEFAULT_DROP_DETECTION_TIMEOUT_SECONDS,
        resume_backoff_seconds: Sequence[float] = DEFAULT_RESUME_BACKOFF_SECONDS,
        client_name: str = MCP_CLIENT_NAME,
        client_version: str | None = None,
    ) -> None:
        self._http_sse_client = http_sse_client
        self._json_codec = json_codec
        self._sdk_event_buffer = sdk_event_buffer
        self._configured_endpoints = list(configured_endpoints)
        self._local_sdk_endpoint = local_sdk_endpoint
        self._default_token = default_token
        self._drop_detection_timeout_seconds = drop_detection_timeout_seconds
        self._resume_backoff_seconds = tuple(resume_backoff_seconds)
        self._client_name = client_name
        self._client_version = (
            client_version
            if client_version is not None
            else importlib.metadata.version(MCP_CLIENT_NAME)
        )
        self._connections: dict[str, _RpcConnection] = {}

    # --- Operations -----------------------------------------------------------------------------

    async def open_rpc_connection(
        self, endpoint: str | None = None, token: str | None = None, certificate: str | None = None
    ) -> RpcConnectionOpenOutcome:
        """Sends ``open_rpc_session``, keeps the session id, then sends ``rpc.discover``.

        ``endpoint`` is a configured endpoint's name or an endpoint URL. With no endpoint, each
        candidate URL of the local SDK endpoint is tried in order: a candidate whose health check
        does not answer ``pass`` is skipped before any token is sent, and the first that answers
        ``open_rpc_session`` is used. The token is the first found of: ``token``; the
        endpoint's configured token (from its ``token_env``); the default token.

        The server must prove it holds the private key of a pinned certificate, read when
        connecting, the first found of: ``certificate`` (a path); the endpoint's configured
        ``certificate_path`` (the local SDK endpoint's too); the default certificate path
        (``http_sse_client.default_sdk_rpc_server_certificate_path``). Without a usable
        certificate nothing is sent. When no candidate opens, a candidate that presented a
        different certificate is reported over the others' failures.
        """
        candidate_endpoints = self._candidate_endpoints(endpoint, token, certificate)
        if not candidate_endpoints:
            return RpcConnectionFailed("no endpoint given and no local SDK endpoint configured")

        certificate_mismatch: RpcConnectionFailed | None = None
        for endpoint_url, endpoint_token, certificate_path in candidate_endpoints:
            ssl_context = _pinned_certificate_ssl_context_from_file(certificate_path)
            if isinstance(ssl_context, RpcConnectionFailed):
                return ssl_context
            if not endpoint:
                health_failure = await self._health_check_failure(endpoint_url, ssl_context, certificate_path)
                if health_failure is not None:
                    open_outcome = health_failure
                    if health_failure.certificate_problem and certificate_mismatch is None:
                        certificate_mismatch = health_failure
                    continue
            connection = _RpcConnection(
                rpc_connection_id="",
                endpoint_url=endpoint_url,
                token=endpoint_token,
                ssl_context=ssl_context,
                certificate_path=certificate_path,
            )
            open_outcome = await self._open_rpc_session(connection)
            if not isinstance(open_outcome, RpcConnectionFailed):
                break
            if open_outcome.certificate_problem and certificate_mismatch is None:
                certificate_mismatch = open_outcome
        if open_outcome is not None:
            if isinstance(open_outcome, RpcConnectionFailed) and certificate_mismatch is not None:
                return certificate_mismatch
            return open_outcome

        discover_outcome, _ = await self._send_single_request(connection, "rpc.discover", {})
        if not isinstance(discover_outcome, RpcResponseReceived):
            return discover_outcome
        openrpc_document = discover_outcome.json_rpc_response.get("result")
        if not isinstance(openrpc_document, dict):
            return discover_outcome
        connection.openrpc_document = openrpc_document

        connection.rpc_connection_id = _next_rpc_connection_id()
        self._connections[connection.rpc_connection_id] = connection
        return RpcConnectionOpened(
            rpc_connection_id=connection.rpc_connection_id,
            sdk_version=connection.sdk_version,
            methods=self.list_rpc_methods(connection.rpc_connection_id),
        )

    async def close_rpc_connection(self, rpc_connection_id: str) -> RpcCommandOutcome:
        """Sends ``end_rpc_session``, stops holding the connection's streams and discards its
        buffered events."""
        connection = self._connection(rpc_connection_id)
        end_outcome = await self._send_command(connection, "end_rpc_session", {})
        for held_subscription in list(connection.held_subscriptions.values()):
            await self._stop_holding_subscription(connection, held_subscription)
        del self._connections[rpc_connection_id]
        self._sdk_event_buffer.discard_connection_events(rpc_connection_id)
        return end_outcome

    def list_rpc_connections(self) -> list[RpcConnectionSummary]:
        return [
            RpcConnectionSummary(
                rpc_connection_id=connection.rpc_connection_id,
                endpoint_url=connection.endpoint_url,
                state=connection.state,
                state_reason=connection.state_reason,
                sdk_version=connection.sdk_version,
                subscription_ids=list(connection.held_subscriptions),
            )
            for connection in self._connections.values()
        ]

    def list_rpc_methods(self, rpc_connection_id: str) -> list[RpcMethodSummary]:
        """The methods and events of the connection's OpenRPC document: name + one-line summary."""
        openrpc_document = self._connection(rpc_connection_id).openrpc_document
        method_summaries = [
            RpcMethodSummary(
                name=method["name"],
                kind="method",
                summary=method.get("summary") or _first_line(method.get("description")),
            )
            for method in openrpc_document.get("methods", [])
        ]
        event_summaries = [
            RpcMethodSummary(
                name=event_name,
                kind="event",
                summary=event_schema.get("summary") or _first_line(event_schema.get("description")),
            )
            for event_name, event_schema in openrpc_document.get(OPENRPC_EVENTS_FIELD, {}).items()
        ]
        return method_summaries + event_summaries

    def describe_rpc_method(
        self, rpc_connection_id: str, name: str
    ) -> RpcMethodDescription | RpcMethodNotFound:
        openrpc_document = self._connection(rpc_connection_id).openrpc_document
        for method in openrpc_document.get("methods", []):
            if method["name"] == name:
                return RpcMethodDescription(
                    name=name, kind="method", description=_with_references_resolved(method, openrpc_document)
                )
        events = openrpc_document.get(OPENRPC_EVENTS_FIELD, {})
        if name in events:
            return RpcMethodDescription(
                name=name, kind="event", description=_with_references_resolved(events[name], openrpc_document)
            )

        known_names = [method["name"] for method in openrpc_document.get("methods", [])]
        known_names.extend(events)
        return RpcMethodNotFound(name=name, suggestions=difflib.get_close_matches(name, known_names))

    async def send_rpc_command(
        self, rpc_connection_id: str, method_name: str, params: dict[str, Any]
    ) -> RpcCommandOutcome:
        """Sends one JSON-RPC request. A single response is returned as it is; a subscription
        stream is held, its events stored in the event buffer, and its subscription id returned;
        a reply of files is returned as its files."""
        connection = self._connection(rpc_connection_id)
        return await self._send_command(connection, method_name, params)

    # --- Requests -------------------------------------------------------------------------------

    def _connection(self, rpc_connection_id: str) -> _RpcConnection:
        connection = self._connections.get(rpc_connection_id)
        if connection is None:
            raise UnknownRpcConnectionError(rpc_connection_id)
        return connection

    def _first_token_found(self, *tokens: str | None) -> str | None:
        for candidate_token in (*tokens, self._default_token):
            if candidate_token is not None:
                return candidate_token
        return None

    @staticmethod
    def _first_certificate_path_found(*certificate_paths: Path | None) -> Path | None:
        for certificate_path in certificate_paths:
            if certificate_path is not None:
                return certificate_path
        return default_sdk_rpc_server_certificate_path()

    def _candidate_endpoints(
        self, endpoint: str | None, token: str | None, certificate: str | None = None
    ) -> list[tuple[str, str | None, Path | None]]:
        """The (URL, token, certificate path) triples to try in order for
        ``open_rpc_connection``."""
        certificate_argument = Path(certificate).expanduser() if certificate else None
        if not endpoint:
            if self._local_sdk_endpoint is None:
                return []
            local_token = self._first_token_found(token, self._local_sdk_endpoint.token)
            local_certificate_path = self._first_certificate_path_found(
                certificate_argument, self._local_sdk_endpoint.certificate_path
            )
            return [
                (candidate_url, local_token, local_certificate_path)
                for candidate_url in _local_sdk_endpoint_candidate_urls(self._local_sdk_endpoint)
            ]
        for configured_endpoint in self._configured_endpoints:
            if endpoint in (configured_endpoint.name, configured_endpoint.url):
                return [
                    (
                        configured_endpoint.url,
                        self._first_token_found(token, configured_endpoint.token),
                        self._first_certificate_path_found(
                            certificate_argument, configured_endpoint.certificate_path
                        ),
                    )
                ]
        return [
            (endpoint, self._first_token_found(token), self._first_certificate_path_found(certificate_argument))
        ]

    async def _open_rpc_session(self, connection: _RpcConnection) -> RpcConnectionOpenOutcome | None:
        """Sends ``open_rpc_session`` and keeps the session id. Returns None when the session
        opened, otherwise the outcome to return."""
        open_outcome, open_reply = await self._send_single_request(
            connection,
            "open_rpc_session",
            {"client_name": self._client_name, "client_version": self._client_version},
        )
        if open_reply is None:
            return open_outcome
        if "error" in open_outcome.json_rpc_response:
            return open_outcome
        rpc_session_id = open_reply.headers.get(RPC_SESSION_ID_REPLY_HEADER)
        if not rpc_session_id:
            return RpcConnectionFailed(f"open_rpc_session reply has no {RPC_SESSION_ID_HEADER} header")
        connection.rpc_session_id = rpc_session_id
        return None

    async def _health_check_failure(
        self, endpoint_url: str, ssl_context: ssl.SSLContext, certificate_path: Path | None
    ) -> RpcConnectionFailed | None:
        """None when the SDK endpoint's health check answers ``pass``; otherwise why not."""
        health_url = str(httpx2.URL(endpoint_url).copy_with(path=HEALTH_ENDPOINT_PATH, query=None))
        try:
            reply = await self._http_sse_client.get(health_url, HEALTH_CHECK_TIMEOUT_SECONDS, ssl_context)
            health = self._json_codec.decode_json(reply.body.decode("utf-8", errors="replace"))
        except (httpx2.HTTPError, JsonCodecError) as error:
            if _is_certificate_verification_failure(error):
                return _certificate_mismatch(endpoint_url, certificate_path)
            return RpcConnectionFailed(f"health check at {health_url} failed: {type(error).__name__}: {error}")
        if reply.status != HTTP_STATUS_OK or not isinstance(health, dict) or health.get("status") != "pass":
            return RpcConnectionFailed(f"health check at {health_url} did not answer status pass")
        return None

    def _request_headers(self, connection: _RpcConnection) -> dict[str, str]:
        headers: dict[str, str] = {}
        # Authorization: Bearer <token> (RFC 6750, https://datatracker.ietf.org/doc/html/rfc6750).
        if connection.token is not None:
            headers["Authorization"] = f"Bearer {connection.token}"
        if connection.rpc_session_id is not None:
            headers[RPC_SESSION_ID_HEADER] = connection.rpc_session_id
        return headers

    async def _post_request(
        self, connection: _RpcConnection, request_id: int, method_name: str, params: dict[str, Any]
    ) -> HttpReply | HttpSseStream | RpcConnectionFailed:
        # JSON-RPC 2.0, params by name (https://www.jsonrpc.org/specification).
        request_body = self._json_codec.encode_json(
            {"jsonrpc": "2.0", "id": request_id, "method": method_name, "params": params}
        ).encode("utf-8")
        try:
            reply = await self._http_sse_client.post(
                connection.endpoint_url,
                self._request_headers(connection),
                request_body,
                JSON_CONTENT_TYPE,
                self._drop_detection_timeout_seconds,
                connection.ssl_context,
            )
        except httpx2.HTTPError as http_error:
            failure = (
                _certificate_mismatch(connection.endpoint_url, connection.certificate_path)
                if _is_certificate_verification_failure(http_error)
                else RpcConnectionFailed(f"{type(http_error).__name__}: {http_error}")
            )
            connection.state = RpcConnectionState.CONNECTION_LOST
            connection.state_reason = failure.reason
            return failure

        if isinstance(reply, HttpReply) and reply.status == HTTP_STATUS_RPC_SESSION_NOT_FOUND:
            connection.state = RpcConnectionState.RPC_SESSION_ENDED
            connection.state_reason = None
        elif connection.state == RpcConnectionState.CONNECTION_LOST:
            connection.state = RpcConnectionState.OPEN
            connection.state_reason = None
        return reply

    def _single_reply_outcome(
        self, reply: HttpReply
    ) -> RpcResponseReceived | RpcHttpStatusReply | RpcConnectionFailed:
        body_text = reply.body.decode("utf-8", errors="replace")
        if reply.status != HTTP_STATUS_OK:
            return RpcHttpStatusReply(status=reply.status, body_text=body_text)
        try:
            json_rpc_response = self._json_codec.decode_json(body_text)
        except JsonCodecError as decode_error:
            return RpcConnectionFailed(f"reply is not a JSON-RPC response: {decode_error}")
        if not isinstance(json_rpc_response, dict):
            return RpcConnectionFailed("reply is not a JSON-RPC response object")
        return RpcResponseReceived(json_rpc_response)

    async def _send_single_request(
        self, connection: _RpcConnection, method_name: str, params: dict[str, Any]
    ) -> tuple[RpcCommandOutcome, HttpReply | None]:
        """A request answered with one JSON-RPC response. Returns the outcome, and the HTTP
        reply when that response was received."""
        reply = await self._post_request(connection, connection.next_request_id(), method_name, params)
        if isinstance(reply, RpcConnectionFailed):
            return reply, None
        if isinstance(reply, HttpSseStream):
            await self._http_sse_client.close_stream(reply)
            return RpcConnectionFailed(f"{method_name} was answered with a stream"), None
        outcome = self._single_reply_outcome(reply)
        return outcome, reply if isinstance(outcome, RpcResponseReceived) else None

    async def _send_command(
        self, connection: _RpcConnection, method_name: str, params: dict[str, Any]
    ) -> RpcCommandOutcome:
        request_id = connection.next_request_id()
        reply = await self._post_request(connection, request_id, method_name, params)
        if isinstance(reply, RpcConnectionFailed):
            return reply
        if isinstance(reply, HttpReply):
            # Like a stream, a reply of files is told apart by its content type alone.
            if reply.status == HTTP_STATUS_OK and reply.headers.get("content-type", "").lower().startswith(
                MULTIPART_MIXED_CONTENT_TYPE
            ):
                files = reply_files(reply)
                if files is None:
                    return RpcConnectionFailed(f"{method_name} reply is not a valid multipart/mixed file reply")
                return RpcFilesReceived(files=files)
            return self._single_reply_outcome(reply)

        acknowledged_event_name = await self._read_subscription_acknowledgement(reply)
        if acknowledged_event_name is None:
            await self._http_sse_client.close_stream(reply)
            return RpcConnectionFailed("subscription stream ended before its acknowledgement")
        # The subscription id is the JSON-RPC id of the request that opened the stream
        # (design reference: Subscription stream messages).
        held_subscription = _HeldSubscription(
            subscription_id=request_id, event_name=acknowledged_event_name, current_stream=reply
        )
        connection.held_subscriptions[request_id] = held_subscription
        held_subscription.holding_task = asyncio.create_task(
            self._hold_subscription(connection, held_subscription)
        )
        return RpcSubscriptionStarted(subscription_id=request_id)

    # --- Subscription streams -------------------------------------------------------------------

    def _decode_stream_message(self, data: str) -> dict[str, Any] | None:
        try:
            message = self._json_codec.decode_json(data)
        except JsonCodecError:
            return None
        return message if isinstance(message, dict) else None

    async def _read_subscription_acknowledgement(self, stream: HttpSseStream) -> str | None:
        """Reads the stream's first message; returns its event name when it is the
        acknowledgement, otherwise None."""
        try:
            first_sse_event = await stream.__anext__()
        except StopAsyncIteration:
            return None
        message = self._decode_stream_message(first_sse_event.data)
        if message is None or message.get("method") != "subscription_acknowledged":
            return None
        return message.get("params", {}).get("event_name")

    def _store_buffered_event(
        self,
        connection: _RpcConnection,
        held_subscription: _HeldSubscription,
        kind: str,
        event_name: str,
        payload: dict[str, Any],
    ) -> None:
        self._sdk_event_buffer.store_event(
            BufferedEvent(
                rpc_connection_id=connection.rpc_connection_id,
                subscription_id=held_subscription.subscription_id,
                kind=kind,
                event_name=event_name,
                payload=payload,
                received_at=time.time(),
            )
        )

    async def _read_stream_until_it_ends(
        self, connection: _RpcConnection, held_subscription: _HeldSubscription, stream: HttpSseStream
    ) -> bool:
        """Stores the stream's events in the buffer. Returns True when the stream ended with its
        final response (the subscription is over), False when it dropped."""
        async for sse_event in stream:
            message = self._decode_stream_message(sse_event.data)
            if message is None:
                continue
            method = message.get("method")
            params = message.get("params", {})
            if method == "subscription_event":
                held_subscription.last_sdk_event_id = params.get(
                    "sdk_event_id", held_subscription.last_sdk_event_id
                )
                self._store_buffered_event(
                    connection,
                    held_subscription,
                    "event",
                    params.get("event_name", held_subscription.event_name),
                    params.get("payload", {}),
                )
            elif method == "subscription_missed_events":
                self._store_buffered_event(
                    connection,
                    held_subscription,
                    "missed_events",
                    held_subscription.event_name,
                    {"oldest_retained_sdk_event_id": params.get("oldest_retained_sdk_event_id")},
                )
            elif "id" in message and ("result" in message or "error" in message):
                await self._http_sse_client.close_stream(stream)
                return True
        return stream.end_reason == SseStreamEndReason.CLOSED_BY_CLIENT

    async def _resume_subscription(
        self, connection: _RpcConnection, held_subscription: _HeldSubscription
    ) -> HttpSseStream | None:
        """Resumes a dropped stream from the last SDK event id: one attempt per backoff delay
        (design reference: Timing and limits). Returns the resumed stream, or None when every
        attempt failed."""
        # Re-issued from the last event id, as a Kubernetes watch resumes from its last
        # resourceVersion (https://kubernetes.io/docs/reference/using-api/api-concepts/).
        for backoff_seconds in self._resume_backoff_seconds:
            await asyncio.sleep(backoff_seconds)
            if held_subscription.stop_requested:
                return None
            reply = await self._post_request(
                connection,
                connection.next_request_id(),
                "resume_subscription",
                {
                    "subscription_id": held_subscription.subscription_id,
                    "last_sdk_event_id": held_subscription.last_sdk_event_id,
                },
            )
            if not isinstance(reply, HttpSseStream):
                continue
            if await self._read_subscription_acknowledgement(reply) is not None:
                return reply
            await self._http_sse_client.close_stream(reply)
        return None

    async def _hold_subscription(
        self, connection: _RpcConnection, held_subscription: _HeldSubscription
    ) -> None:
        while held_subscription.current_stream is not None:
            subscription_is_over = await self._read_stream_until_it_ends(
                connection, held_subscription, held_subscription.current_stream
            )
            held_subscription.current_stream = None
            if subscription_is_over or held_subscription.stop_requested:
                break
            resumed_stream = await self._resume_subscription(connection, held_subscription)
            if held_subscription.stop_requested:
                if resumed_stream is not None:
                    await self._http_sse_client.close_stream(resumed_stream)
                break
            if resumed_stream is None:
                self._store_buffered_event(
                    connection,
                    held_subscription,
                    "reconnect_failed",
                    held_subscription.event_name,
                    {"reason": RECONNECT_FAILED_REASON},
                )
                break
            held_subscription.current_stream = resumed_stream
        connection.held_subscriptions.pop(held_subscription.subscription_id, None)

    async def _stop_holding_subscription(
        self, connection: _RpcConnection, held_subscription: _HeldSubscription
    ) -> None:
        held_subscription.stop_requested = True
        if held_subscription.current_stream is not None:
            await self._http_sse_client.close_stream(held_subscription.current_stream)
        holding_task = held_subscription.holding_task
        if holding_task is not None and not holding_task.done():
            holding_task.cancel()
            await asyncio.gather(holding_task, return_exceptions=True)
        connection.held_subscriptions.pop(held_subscription.subscription_id, None)
