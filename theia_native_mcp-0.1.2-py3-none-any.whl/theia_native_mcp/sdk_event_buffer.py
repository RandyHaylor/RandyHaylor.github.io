"""The MCP server's per-connection buffer of received SDK events: sequence numbers, paging, waiting."""

from __future__ import annotations

import asyncio
from collections import deque
from collections.abc import Callable, Sequence
from dataclasses import dataclass, field
from typing import Literal

from theia_native_mcp.sdk_event_filter import Filter, event_matches_filter

MAX_BUFFERED_EVENTS_PER_CONNECTION = 10_000

BufferedEventKind = Literal["event", "missed_events", "reconnect_failed"]


@dataclass
class BufferedEvent:
    rpc_connection_id: str
    subscription_id: str | int
    kind: BufferedEventKind
    event_name: str
    payload: dict
    received_at: float
    sequence_number: int = 0


@dataclass(frozen=True)
class BufferedEventPage:
    """Events after a position, the position to read from next, and whether events were missed.

    `position_older_than_oldest_held` is True when events after the requested position were
    already dropped from the buffer.
    """

    events: list[BufferedEvent]
    next_position: int
    position_older_than_oldest_held: bool


@dataclass(eq=False)
class _EventWaiter:
    event_matches: Callable[[BufferedEvent], bool]
    matching_event_future: asyncio.Future[BufferedEvent]


@dataclass
class _ConnectionEvents:
    events: deque[BufferedEvent] = field(
        default_factory=lambda: deque(maxlen=MAX_BUFFERED_EVENTS_PER_CONNECTION)
    )
    last_sequence_number: int = 0
    waiters: list[_EventWaiter] = field(default_factory=list)


def _validate_filter(event_filter: Filter | None) -> None:
    """Raises SdkEventFilterError now, rather than when the first event is matched."""
    filter_check_event = BufferedEvent("", "", "event", "", {}, 0.0)
    event_matches_filter(filter_check_event, event_filter)


def _event_passes_filter(event: BufferedEvent, event_filter: Filter | None) -> bool:
    # missed_events and reconnect_failed are about the subscription itself, so they always pass.
    if event.kind != "event":
        return True
    return event_matches_filter(event, event_filter)


class SdkEventBuffer:
    """Holds up to 10,000 events per connection, oldest dropped first.

    Asyncio-safe: every operation runs on the event loop thread without awaiting while it
    touches the buffer, so no operation sees another half done.
    """

    def __init__(self) -> None:
        self._events_by_connection: dict[str, _ConnectionEvents] = {}

    def store_event(self, event: BufferedEvent) -> int:
        """Stores the event with the connection's next sequence number and returns that number."""
        connection_events = self._events_by_connection.setdefault(
            event.rpc_connection_id, _ConnectionEvents()
        )
        connection_events.last_sequence_number += 1
        event.sequence_number = connection_events.last_sequence_number
        connection_events.events.append(event)

        still_waiting: list[_EventWaiter] = []
        for waiter in connection_events.waiters:
            if waiter.matching_event_future.done():
                continue
            if waiter.event_matches(event):
                waiter.matching_event_future.set_result(event)
            else:
                still_waiting.append(waiter)
        connection_events.waiters = still_waiting
        return event.sequence_number

    def read_events_after(
        self,
        rpc_connection_id: str,
        position: int,
        event_name: str | None,
        event_filter: Filter | None,
        limit: int,
    ) -> BufferedEventPage:
        """Events with a sequence number after `position`, matching the name and filter, up to `limit`.

        Raises SdkEventFilterError if the filter is invalid.
        """
        _validate_filter(event_filter)
        connection_events = self._events_by_connection.get(rpc_connection_id)
        if connection_events is None or not connection_events.events:
            return BufferedEventPage([], position, False)

        oldest_held_sequence_number = connection_events.events[0].sequence_number
        position_older_than_oldest_held = position < oldest_held_sequence_number - 1

        matching_events: list[BufferedEvent] = []
        next_position = max(position, connection_events.last_sequence_number)
        for event in connection_events.events:
            if event.sequence_number <= position:
                continue
            if event_name is not None and event.event_name != event_name:
                continue
            if not _event_passes_filter(event, event_filter):
                continue
            matching_events.append(event)
            if len(matching_events) == limit:
                next_position = event.sequence_number
                break

        return BufferedEventPage(matching_events, next_position, position_older_than_oldest_held)

    async def wait_for_next_matching_event(
        self,
        rpc_connection_id: str,
        subscription_ids_or_event_names: Sequence[str | int],
        event_filter: Filter | None,
        timeout: float,
        after_position: int | None = None,
    ) -> BufferedEvent | None:
        """The first matching event stored after the call, or after `after_position` when given.

        An event matches when its subscription id or event name is one of
        `subscription_ids_or_event_names` and, for kind `event` only, it matches the filter.
        Returns None on timeout. Raises SdkEventFilterError if the filter is invalid.
        """
        _validate_filter(event_filter)
        wanted_ids_or_names = list(subscription_ids_or_event_names)

        def event_matches(event: BufferedEvent) -> bool:
            is_wanted = (
                event.subscription_id in wanted_ids_or_names
                or event.event_name in wanted_ids_or_names
            )
            return is_wanted and _event_passes_filter(event, event_filter)

        connection_events = self._events_by_connection.setdefault(
            rpc_connection_id, _ConnectionEvents()
        )
        if after_position is not None:
            for event in connection_events.events:
                if event.sequence_number > after_position and event_matches(event):
                    return event

        matching_event_future: asyncio.Future[BufferedEvent] = (
            asyncio.get_running_loop().create_future()
        )
        waiter = _EventWaiter(event_matches, matching_event_future)
        connection_events.waiters.append(waiter)
        try:
            return await asyncio.wait_for(matching_event_future, timeout)
        except asyncio.TimeoutError:
            return None
        finally:
            if waiter in connection_events.waiters:
                connection_events.waiters.remove(waiter)
            # An entry made only for this wait (no events ever stored, nobody else waiting) is
            # removed, so waiting on an unknown or discarded connection leaves nothing behind.
            if (
                not connection_events.waiters
                and connection_events.last_sequence_number == 0
                and self._events_by_connection.get(rpc_connection_id) is connection_events
            ):
                del self._events_by_connection[rpc_connection_id]

    def discard_connection_events(self, rpc_connection_id: str) -> None:
        """Drops every event held for the connection."""
        self._events_by_connection.pop(rpc_connection_id, None)
