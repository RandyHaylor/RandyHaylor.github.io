"""McpServerSettings: loads the MCP server's settings from its settings file and environment.

Settings file: JSON at the path in ``THEIA_MCP_SETTINGS``::

    {"endpoints": [{"name": "...", "url": "https://127.0.0.1:17420/v1", "token_env": "...",
                    "certificate": "~/sdk_host/sdk_rpc_server_cert.pem"}],
     "local_sdk_endpoint": {"address": "127.0.0.1", "port": 17420, "port_step": 2000,
                            "port_attempts": 5, "token_env": "THEIA_RPC_TOKEN",
                            "certificate": "~/.theia/rpc_tls/sdk_rpc_server_cert.pem"},
     "default_token": "theia_mcp_default_token",
     "knowledgebase": {"default_max_length": 5000}}

Every key is optional; a missing key, or a missing file, gives the built-in default (no
endpoints). The Streamable HTTP bearer secret comes from ``THEIA_MCP_HTTP_SECRET``; each
endpoint's token, and the local SDK endpoint's, comes from the environment variable its
``token_env`` names. An endpoint's ``certificate``, and the local SDK endpoint's, is the path of
that SDK's RPC certificate or a copy of it (``~`` expanded); without it, the default certificate
path is used (``http_sse_client.default_sdk_rpc_server_certificate_path``).
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path

SETTINGS_PATH_ENVIRONMENT_VARIABLE = "THEIA_MCP_SETTINGS"
HTTP_SECRET_ENVIRONMENT_VARIABLE = "THEIA_MCP_HTTP_SECRET"
DEFAULT_KNOWLEDGEBASE_MAX_LENGTH = 5000
DEFAULT_LOCAL_SDK_ENDPOINT_ADDRESS = "127.0.0.1"
DEFAULT_LOCAL_SDK_ENDPOINT_PORT = 17420
DEFAULT_LOCAL_SDK_ENDPOINT_PORT_STEP = 2000
DEFAULT_LOCAL_SDK_ENDPOINT_PORT_ATTEMPTS = 5
DEFAULT_LOCAL_SDK_ENDPOINT_TOKEN_ENV = "THEIA_RPC_TOKEN"
DEFAULT_TOKEN = "theia_mcp_default_token"


@dataclass(frozen=True)
class SdkEndpointSettings:
    name: str
    url: str
    token: str | None
    certificate_path: Path | None = None


@dataclass(frozen=True)
class LocalSdkEndpointSettings:
    """The SDK endpoint ``connect`` tries when given no endpoint; its candidate ports follow the
    SDK's own port rule (design reference: SDK config file)."""

    address: str = DEFAULT_LOCAL_SDK_ENDPOINT_ADDRESS
    port: int = DEFAULT_LOCAL_SDK_ENDPOINT_PORT
    port_step: int = DEFAULT_LOCAL_SDK_ENDPOINT_PORT_STEP
    port_attempts: int = DEFAULT_LOCAL_SDK_ENDPOINT_PORT_ATTEMPTS
    token_env: str = DEFAULT_LOCAL_SDK_ENDPOINT_TOKEN_ENV
    token: str | None = None
    certificate_path: Path | None = None


@dataclass(frozen=True)
class KnowledgebaseSettings:
    default_max_length: int = DEFAULT_KNOWLEDGEBASE_MAX_LENGTH


@dataclass(frozen=True)
class McpServerSettings:
    endpoints: list[SdkEndpointSettings] = field(default_factory=list)
    local_sdk_endpoint: LocalSdkEndpointSettings = field(default_factory=LocalSdkEndpointSettings)
    default_token: str = DEFAULT_TOKEN
    http_secret: str | None = None
    knowledgebase: KnowledgebaseSettings = field(default_factory=KnowledgebaseSettings)


def _read_settings_file() -> dict:
    settings_path = os.environ.get(SETTINGS_PATH_ENVIRONMENT_VARIABLE)
    if not settings_path:
        return {}
    # An MCP client's env block passes the path unexpanded, so expand "~" here.
    settings_file = Path(settings_path).expanduser()
    if not settings_file.is_file():
        return {}
    # utf-8-sig also reads files saved with a UTF-8 byte-order mark (Windows PowerShell 5.1).
    return json.loads(settings_file.read_text(encoding="utf-8-sig"))


def _endpoint_from_file_entry(endpoint_entry: dict) -> SdkEndpointSettings:
    token_environment_variable = endpoint_entry.get("token_env")
    token = os.environ.get(token_environment_variable) if token_environment_variable else None
    certificate = endpoint_entry.get("certificate")
    return SdkEndpointSettings(
        name=endpoint_entry["name"],
        url=endpoint_entry["url"],
        token=token,
        certificate_path=Path(certificate).expanduser() if certificate else None,
    )


def _local_sdk_endpoint_from_file_entry(local_sdk_endpoint_entry: dict) -> LocalSdkEndpointSettings:
    token_environment_variable = local_sdk_endpoint_entry.get(
        "token_env", DEFAULT_LOCAL_SDK_ENDPOINT_TOKEN_ENV
    )
    certificate = local_sdk_endpoint_entry.get("certificate")
    return LocalSdkEndpointSettings(
        address=local_sdk_endpoint_entry.get("address", DEFAULT_LOCAL_SDK_ENDPOINT_ADDRESS),
        port=local_sdk_endpoint_entry.get("port", DEFAULT_LOCAL_SDK_ENDPOINT_PORT),
        port_step=local_sdk_endpoint_entry.get("port_step", DEFAULT_LOCAL_SDK_ENDPOINT_PORT_STEP),
        port_attempts=local_sdk_endpoint_entry.get(
            "port_attempts", DEFAULT_LOCAL_SDK_ENDPOINT_PORT_ATTEMPTS
        ),
        token_env=token_environment_variable,
        token=os.environ.get(token_environment_variable) if token_environment_variable else None,
        certificate_path=Path(certificate).expanduser() if certificate else None,
    )


def load_mcp_server_settings() -> McpServerSettings:
    settings_file_contents = _read_settings_file()

    endpoints = [
        _endpoint_from_file_entry(endpoint_entry)
        for endpoint_entry in settings_file_contents.get("endpoints", [])
    ]

    knowledgebase_entry = settings_file_contents.get("knowledgebase", {})
    knowledgebase = KnowledgebaseSettings(
        default_max_length=knowledgebase_entry.get(
            "default_max_length", DEFAULT_KNOWLEDGEBASE_MAX_LENGTH
        )
    )

    return McpServerSettings(
        endpoints=endpoints,
        local_sdk_endpoint=_local_sdk_endpoint_from_file_entry(
            settings_file_contents.get("local_sdk_endpoint", {})
        ),
        default_token=settings_file_contents.get("default_token", DEFAULT_TOKEN),
        http_secret=os.environ.get(HTTP_SECRET_ENVIRONMENT_VARIABLE),
        knowledgebase=knowledgebase,
    )
