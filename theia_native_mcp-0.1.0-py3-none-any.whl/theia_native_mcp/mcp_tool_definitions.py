"""McpToolDefinitions: the ten MCP tools the agent sees, each calling the module that does the work.

Every tool has an explicit input schema (its typed parameters) and output schema (its
``TypedDict`` result), both published by the MCP Python SDK. Each tool returns the owning
module's response, results and errors alike; the tools take no action of their own on an
error. An SDK JSON-RPC error is returned as ``{"error": {"code", "message", "data"}}``.
"""

from __future__ import annotations

import importlib.resources
import json
import tempfile
from pathlib import Path, PurePosixPath
from typing import Annotated, Any

from mcp.server import MCPServer
from mcp.server.mcpserver.exceptions import ToolError
from pydantic import Field
from typing_extensions import NotRequired, TypedDict

from theia_native_mcp.http_sse_client import ReplyFile
from theia_native_mcp.knowledgebase_manager import KnowledgebaseManager
from theia_native_mcp.rpc_connection_manager import (
    RpcConnectionFailed,
    RpcConnectionManager,
    RpcConnectionOpened,
    RpcConnectionSummary,
    RpcFilesReceived,
    RpcHttpStatusReply,
    RpcMethodDescription,
    RpcMethodSummary,
    RpcResponseReceived,
    RpcSubscriptionStarted,
    UnknownRpcConnectionError,
)
from theia_native_mcp.sdk_event_buffer import BufferedEvent, SdkEventBuffer
from theia_native_mcp.sdk_event_filter import SdkEventFilterError

# --- Output shapes -----------------------------------------------------------------------------


class JsonRpcErrorOutput(TypedDict):
    code: int
    message: str
    data: Any


class HttpStatusReplyOutput(TypedDict):
    status: int
    body_text: str


class ConnectionFailedOutput(TypedDict):
    reason: str


class MethodSummaryOutput(TypedDict):
    name: str
    kind: str
    summary: str


class ConnectOutput(TypedDict):
    rpc_connection_id: NotRequired[str]
    sdk_version: NotRequired[str | None]
    methods: NotRequired[list[MethodSummaryOutput]]
    result: NotRequired[Any]
    error: NotRequired[JsonRpcErrorOutput]
    http_status_reply: NotRequired[HttpStatusReplyOutput]
    connection_failed: NotRequired[ConnectionFailedOutput]
    guidance: NotRequired[str]


class DisconnectOutput(TypedDict):
    rpc_connection_id: str
    disconnected: bool
    result: NotRequired[Any]
    error: NotRequired[JsonRpcErrorOutput]
    http_status_reply: NotRequired[HttpStatusReplyOutput]
    connection_failed: NotRequired[ConnectionFailedOutput]


class ConnectionSummaryOutput(TypedDict):
    rpc_connection_id: str
    endpoint_url: str
    state: str
    state_reason: str | None
    sdk_version: str | None
    subscription_ids: list[str | int]


class ListConnectionsOutput(TypedDict):
    connections: list[ConnectionSummaryOutput]


class ListMethodsOutput(TypedDict):
    methods: list[MethodSummaryOutput]


class MethodNotFoundOutput(TypedDict):
    name: str
    suggestions: list[str]


class DescribeMethodOutput(TypedDict):
    name: NotRequired[str]
    kind: NotRequired[str]
    description: NotRequired[dict[str, Any]]
    method_not_found: NotRequired[MethodNotFoundOutput]


class DownloadedFileOutput(TypedDict):
    file_name: str
    path: str
    size_bytes: int


class CallMethodOutput(TypedDict):
    result: NotRequired[Any]
    subscription_id: NotRequired[str | int]
    files_downloaded: NotRequired[list[DownloadedFileOutput]]
    error: NotRequired[JsonRpcErrorOutput]
    http_status_reply: NotRequired[HttpStatusReplyOutput]
    connection_failed: NotRequired[ConnectionFailedOutput]
    guidance: NotRequired[str]


class BufferedEventOutput(TypedDict):
    sequence_number: int
    rpc_connection_id: str
    subscription_id: str | int
    kind: str
    event_name: str
    payload: dict[str, Any]
    received_at: float


class GetEventsOutput(TypedDict):
    events: list[BufferedEventOutput]
    next_position: int
    position_older_than_oldest_held: bool


class WaitForEventOutput(TypedDict):
    timed_out: bool
    event: NotRequired[BufferedEventOutput]


class KnowledgebaseIndexOutput(TypedDict):
    index: str


class ReadKnowledgebaseOutput(TypedDict):
    text: str
    total_characters: int
    truncated: bool
    next_start_index: int | None
    version_note: str | None


# --- Converting module responses to tool results ---------------------------------------------


def _method_summary_output(method_summary: RpcMethodSummary) -> MethodSummaryOutput:
    return {"name": method_summary.name, "kind": method_summary.kind, "summary": method_summary.summary}


def _connection_summary_output(connection_summary: RpcConnectionSummary) -> ConnectionSummaryOutput:
    return {
        "rpc_connection_id": connection_summary.rpc_connection_id,
        "endpoint_url": connection_summary.endpoint_url,
        "state": connection_summary.state.value,
        "state_reason": connection_summary.state_reason,
        "sdk_version": connection_summary.sdk_version,
        "subscription_ids": list(connection_summary.subscription_ids),
    }


def _buffered_event_output(event: BufferedEvent) -> BufferedEventOutput:
    return {
        "sequence_number": event.sequence_number,
        "rpc_connection_id": event.rpc_connection_id,
        "subscription_id": event.subscription_id,
        "kind": event.kind,
        "event_name": event.event_name,
        "payload": event.payload,
        "received_at": event.received_at,
    }


def _save_downloaded_files(files: list[ReplyFile], directory: Path) -> dict[str, Any]:
    """Writes each file under ``directory`` at its name (a relative path) and reports where.
    A name that is absolute or leaves ``directory`` is refused, and nothing is written."""
    targets = []
    for reply_file in files:
        name = PurePosixPath(reply_file.file_name)
        if (
            not name.parts
            or name.is_absolute()
            or any(part in ("", ".", "..") or "\\" in part or ":" in part for part in name.parts)
        ):
            return {"connection_failed": {"reason": f"refused a downloaded file name: {reply_file.file_name!r}"}}
        targets.append((reply_file, directory.joinpath(*name.parts)))
    downloaded = []
    for reply_file, target in targets:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(reply_file.content)
        downloaded.append(
            {"file_name": reply_file.file_name, "path": str(target), "size_bytes": len(reply_file.content)}
        )
    return {"files_downloaded": downloaded}


def _rpc_outcome_output(
    outcome: RpcResponseReceived | RpcSubscriptionStarted | RpcHttpStatusReply | RpcConnectionFailed,
) -> dict[str, Any]:
    """The fields of a tool result that report what an RPC request got back."""
    if isinstance(outcome, RpcResponseReceived):
        json_rpc_response = outcome.json_rpc_response
        if "error" in json_rpc_response:
            json_rpc_error = json_rpc_response["error"]
            return {
                "error": {
                    "code": json_rpc_error.get("code"),
                    "message": json_rpc_error.get("message"),
                    "data": json_rpc_error.get("data"),
                }
            }
        return {"result": json_rpc_response.get("result")}
    if isinstance(outcome, RpcSubscriptionStarted):
        return {"subscription_id": outcome.subscription_id}
    if isinstance(outcome, RpcHttpStatusReply):
        return {"http_status_reply": {"status": outcome.status, "body_text": outcome.body_text}}
    return {"connection_failed": {"reason": outcome.reason}}


def _unknown_rpc_connection_tool_error(rpc_connection_id: str) -> ToolError:
    return ToolError(f"unknown rpc_connection_id: {rpc_connection_id}")


# --- Agent-facing text -------------------------------------------------------------------------

MCP_AGENT_TEXT_FILE_NAME = "mcp_agent_text.json"
SDK_TOKEN_REJECTED_HTTP_STATUS = 401


def load_mcp_agent_text() -> dict[str, Any]:
    """The server instructions, tool and parameter descriptions and result guidance from ``mcp_agent_text.json``."""
    agent_text_file = importlib.resources.files("theia_native_mcp").joinpath(MCP_AGENT_TEXT_FILE_NAME)
    return json.loads(agent_text_file.read_text(encoding="utf-8"))


MCP_AGENT_TEXT = load_mcp_agent_text()
TOOL_DESCRIPTIONS: dict[str, str] = MCP_AGENT_TEXT["tool_descriptions"]
PARAMETER_DESCRIPTIONS: dict[str, dict[str, str]] = MCP_AGENT_TEXT["parameter_descriptions"]
RESULT_GUIDANCE: dict[str, str] = MCP_AGENT_TEXT["result_guidance"]


def _described_parameter(tool_name: str, parameter_name: str) -> Any:
    """The pydantic field carrying a tool parameter's description from the agent text file."""
    return Field(description=PARAMETER_DESCRIPTIONS[tool_name][parameter_name])


def _with_sdk_token_rejected_guidance(
    outcome: RpcResponseReceived | RpcSubscriptionStarted | RpcHttpStatusReply | RpcConnectionFailed,
    tool_result: dict[str, Any],
) -> dict[str, Any]:
    """The tool result, with the token guidance added when the SDK replied 401."""
    if isinstance(outcome, RpcHttpStatusReply) and outcome.status == SDK_TOKEN_REJECTED_HTTP_STATUS:
        return {**tool_result, "guidance": RESULT_GUIDANCE["sdk_token_rejected"]}
    return tool_result


class McpToolDefinitions:
    """The ten tools, registered on an MCP server; each calls the module that does the work."""

    def __init__(
        self,
        rpc_connection_manager: RpcConnectionManager,
        sdk_event_buffer: SdkEventBuffer,
        knowledgebase_manager: KnowledgebaseManager,
        downloaded_files_directory: Path | None = None,
    ) -> None:
        """``downloaded_files_directory``: where files an SDK method sends are saved, one
        folder per connection; default ``<system temp>/theia_native_mcp/downloads``."""
        self._rpc_connection_manager = rpc_connection_manager
        self._sdk_event_buffer = sdk_event_buffer
        self._knowledgebase_manager = knowledgebase_manager
        self._downloaded_files_directory = (
            downloaded_files_directory
            if downloaded_files_directory is not None
            else Path(tempfile.gettempdir()) / "theia_native_mcp" / "downloads"
        )

    def register_mcp_tools(self, mcp_server: MCPServer) -> None:
        tools = {
            "connect": self.connect,
            "disconnect": self.disconnect,
            "list_connections": self.list_connections,
            "list_methods": self.list_methods,
            "describe_method": self.describe_method,
            "call_method": self.call_method,
            "get_events": self.get_events,
            "wait_for_event": self.wait_for_event,
            "get_knowledgebase_index": self.get_knowledgebase_index,
            "read_knowledgebase": self.read_knowledgebase,
        }
        for tool_name, tool_function in tools.items():
            mcp_server.add_tool(tool_function, name=tool_name, description=TOOL_DESCRIPTIONS[tool_name])

    # --- Connection tools -----------------------------------------------------------------------

    async def connect(
        self,
        endpoint: Annotated[str | None, _described_parameter("connect", "endpoint")] = None,
        token: Annotated[str | None, _described_parameter("connect", "token")] = None,
    ) -> ConnectOutput:
        outcome = await self._rpc_connection_manager.open_rpc_connection(endpoint, token)
        if isinstance(outcome, RpcConnectionOpened):
            return {
                "rpc_connection_id": outcome.rpc_connection_id,
                "sdk_version": outcome.sdk_version,
                "methods": [_method_summary_output(method) for method in outcome.methods],
            }
        return _with_sdk_token_rejected_guidance(outcome, _rpc_outcome_output(outcome))

    async def disconnect(
        self, rpc_connection_id: Annotated[str, _described_parameter("disconnect", "rpc_connection_id")]
    ) -> DisconnectOutput:
        try:
            outcome = await self._rpc_connection_manager.close_rpc_connection(rpc_connection_id)
        except UnknownRpcConnectionError:
            raise _unknown_rpc_connection_tool_error(rpc_connection_id) from None
        return {"rpc_connection_id": rpc_connection_id, "disconnected": True, **_rpc_outcome_output(outcome)}

    async def list_connections(self) -> ListConnectionsOutput:
        return {
            "connections": [
                _connection_summary_output(connection_summary)
                for connection_summary in self._rpc_connection_manager.list_rpc_connections()
            ]
        }

    # --- Method tools ---------------------------------------------------------------------------

    async def list_methods(
        self, rpc_connection_id: Annotated[str, _described_parameter("list_methods", "rpc_connection_id")]
    ) -> ListMethodsOutput:
        try:
            methods = self._rpc_connection_manager.list_rpc_methods(rpc_connection_id)
        except UnknownRpcConnectionError:
            raise _unknown_rpc_connection_tool_error(rpc_connection_id) from None
        return {"methods": [_method_summary_output(method) for method in methods]}

    async def describe_method(
        self,
        rpc_connection_id: Annotated[str, _described_parameter("describe_method", "rpc_connection_id")],
        name: Annotated[str, _described_parameter("describe_method", "name")],
    ) -> DescribeMethodOutput:
        try:
            description = self._rpc_connection_manager.describe_rpc_method(rpc_connection_id, name)
        except UnknownRpcConnectionError:
            raise _unknown_rpc_connection_tool_error(rpc_connection_id) from None
        if isinstance(description, RpcMethodDescription):
            return {"name": description.name, "kind": description.kind, "description": description.description}
        return {"method_not_found": {"name": description.name, "suggestions": list(description.suggestions)}}

    async def call_method(
        self,
        rpc_connection_id: Annotated[str, _described_parameter("call_method", "rpc_connection_id")],
        method: Annotated[str, _described_parameter("call_method", "method")],
        params: Annotated[dict[str, Any], _described_parameter("call_method", "params")],
    ) -> CallMethodOutput:
        try:
            outcome = await self._rpc_connection_manager.send_rpc_command(rpc_connection_id, method, params)
        except UnknownRpcConnectionError:
            raise _unknown_rpc_connection_tool_error(rpc_connection_id) from None
        if isinstance(outcome, RpcFilesReceived):
            return _save_downloaded_files(outcome.files, self._downloaded_files_directory / rpc_connection_id)
        return _with_sdk_token_rejected_guidance(outcome, _rpc_outcome_output(outcome))

    # --- Event tools ----------------------------------------------------------------------------

    async def get_events(
        self,
        rpc_connection_id: Annotated[str, _described_parameter("get_events", "rpc_connection_id")],
        position: Annotated[int, _described_parameter("get_events", "position")],
        limit: Annotated[int, _described_parameter("get_events", "limit")],
        event_name: Annotated[str | None, _described_parameter("get_events", "event_name")] = None,
        filter: Annotated[list[str] | None, _described_parameter("get_events", "filter")] = None,  # noqa: A002 - the tool's parameter name
    ) -> GetEventsOutput:
        try:
            page = self._sdk_event_buffer.read_events_after(rpc_connection_id, position, event_name, filter, limit)
        except SdkEventFilterError as filter_error:
            raise ToolError(str(filter_error)) from None
        return {
            "events": [_buffered_event_output(event) for event in page.events],
            "next_position": page.next_position,
            "position_older_than_oldest_held": page.position_older_than_oldest_held,
        }

    async def wait_for_event(
        self,
        rpc_connection_id: Annotated[str, _described_parameter("wait_for_event", "rpc_connection_id")],
        subscription_ids_or_event_names: Annotated[
            list[str | int], _described_parameter("wait_for_event", "subscription_ids_or_event_names")
        ],
        timeout: Annotated[float, _described_parameter("wait_for_event", "timeout")],
        filter: Annotated[list[str] | None, _described_parameter("wait_for_event", "filter")] = None,  # noqa: A002 - the tool's parameter name
        after_position: Annotated[int | None, _described_parameter("wait_for_event", "after_position")] = None,
    ) -> WaitForEventOutput:
        try:
            event = await self._sdk_event_buffer.wait_for_next_matching_event(
                rpc_connection_id, subscription_ids_or_event_names, filter, timeout, after_position
            )
        except SdkEventFilterError as filter_error:
            raise ToolError(str(filter_error)) from None
        if event is None:
            return {"timed_out": True}
        return {"timed_out": False, "event": _buffered_event_output(event)}

    # --- Knowledgebase tools --------------------------------------------------------------------

    def _knowledgebase_version(self) -> str | None:
        """The SDK version of the only connection; none with several connections or none yet."""
        connections = self._rpc_connection_manager.list_rpc_connections()
        if len(connections) != 1:
            return None
        return connections[0].sdk_version

    async def get_knowledgebase_index(
        self,
        anchor: Annotated[str, _described_parameter("get_knowledgebase_index", "anchor")],
    ) -> KnowledgebaseIndexOutput:
        try:
            index = self._knowledgebase_manager.get_knowledgebase_index(anchor, self._knowledgebase_version())
        except LookupError as not_found:
            raise ToolError(str(not_found)) from None
        return {"index": index}

    async def read_knowledgebase(
        self,
        anchor: Annotated[str, _described_parameter("read_knowledgebase", "anchor")],
        start_index: Annotated[int, _described_parameter("read_knowledgebase", "start_index")] = 0,
        max_length: Annotated[int | None, _described_parameter("read_knowledgebase", "max_length")] = None,
    ) -> ReadKnowledgebaseOutput:
        try:
            return self._knowledgebase_manager.read_knowledgebase(
                anchor, start_index, max_length, self._knowledgebase_version()
            )
        except LookupError as not_found:
            raise ToolError(str(not_found)) from None
