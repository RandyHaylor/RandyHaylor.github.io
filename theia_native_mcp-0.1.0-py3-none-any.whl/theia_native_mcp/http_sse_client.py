"""A generic HTTP + SSE client: POST a body, return the HTTP reply or the SSE events of a
``text/event-stream`` reply, and read the files of a ``multipart/mixed`` reply. It carries
whatever body and headers it is given.

Only ``https://`` URLs are accepted. Servers are verified against one pinned certificate, by
default the SDK RPC control server's (``sdk_rpc_server_cert.pem``, shipped with this package): a
server that cannot prove it holds that certificate's private key is refused before any request,
and so any token, is sent.
"""

from __future__ import annotations

import asyncio
import email.parser
import email.policy
import ssl
from collections.abc import AsyncIterator
from dataclasses import dataclass
from enum import Enum
from importlib import resources

import httpx2

SSE_CONTENT_TYPE = "text/event-stream"
MULTIPART_MIXED_CONTENT_TYPE = "multipart/mixed"
SDK_RPC_SERVER_CERTIFICATE_FILE_NAME = "sdk_rpc_server_cert.pem"


def sdk_rpc_server_certificate_pem() -> str:
    """The SDK RPC control server's certificate, shipped with this package."""
    return (
        resources.files("theia_native_mcp")
        .joinpath(SDK_RPC_SERVER_CERTIFICATE_FILE_NAME)
        .read_text(encoding="utf-8")
    )


def pinned_certificate_ssl_context(certificate_pem: str) -> ssl.SSLContext:
    """Trusts exactly ``certificate_pem``. The host name is not checked: the certificate is
    pinned, so it identifies the SDK wherever it runs (a remote host included)."""
    context = ssl.create_default_context(cadata=certificate_pem)
    context.check_hostname = False
    context.verify_mode = ssl.CERT_REQUIRED
    return context


@dataclass(frozen=True)
class HttpReply:
    status: int
    headers: dict[str, str]  # header names in lower case
    body: bytes


@dataclass(frozen=True)
class SseEvent:
    event_name: str
    data: str


class SseStreamEndReason(Enum):
    CLOSED = "closed"
    ERROR = "error"
    IDLE_TIMEOUT = "idle_timeout"
    CLOSED_BY_CLIENT = "closed_by_client"


def reply_is_event_stream(response: httpx2.Response) -> bool:
    media_type, _, _ = response.headers.get("content-type", "").partition(";")
    return media_type.strip().lower() == SSE_CONTENT_TYPE


@dataclass(frozen=True)
class ReplyFile:
    file_name: str
    content: bytes


def reply_files(reply: HttpReply) -> list[ReplyFile] | None:
    """The files of a ``multipart/mixed`` reply (RFC 2046 section 5.1,
    https://www.rfc-editor.org/rfc/rfc2046#section-5.1), each part named by its
    Content-Disposition filename (RFC 6266). None when the reply is not multipart/mixed or a
    part has no file name."""
    content_type = reply.headers.get("content-type", "")
    media_type, _, _ = content_type.partition(";")
    if media_type.strip().lower() != MULTIPART_MIXED_CONTENT_TYPE:
        return None
    message = email.parser.BytesParser(policy=email.policy.HTTP).parsebytes(
        b"Content-Type: " + content_type.encode("latin-1") + b"\r\n\r\n" + reply.body
    )
    if not message.is_multipart():
        return None
    files = []
    for part in message.iter_parts():
        file_name = part.get_filename()
        if not file_name:
            return None
        files.append(ReplyFile(file_name=file_name, content=part.get_payload(decode=True) or b""))
    return files


class HttpSseStream:
    """The SSE events of one ``text/event-stream`` reply, as an async iterator of
    ``SseEvent``. ``end_reason`` is ``None`` while the stream is open and says how it ended
    once iteration has finished."""

    def __init__(self, http_client: httpx2.AsyncClient, response: httpx2.Response) -> None:
        self._http_client = http_client
        self._response = response
        self._events = self._read_events_from_response()
        self._closed_by_client = asyncio.Event()
        self._finished = asyncio.Event()
        self._event_read_in_progress = False
        self.end_reason: SseStreamEndReason | None = None

    def __aiter__(self) -> HttpSseStream:
        return self

    async def __anext__(self) -> SseEvent:
        if self.end_reason is not None:
            raise StopAsyncIteration
        self._event_read_in_progress = True
        try:
            return await self._read_next_event_unless_closed_by_client()
        finally:
            self._event_read_in_progress = False

    async def close_from_client(self) -> None:
        """Ends the stream. A read waiting in another task stops and ends the iteration."""
        self._closed_by_client.set()
        if self._event_read_in_progress:
            await self._finished.wait()
        else:
            await self._finish(SseStreamEndReason.CLOSED_BY_CLIENT)

    async def _read_next_event_unless_closed_by_client(self) -> SseEvent:
        next_event_task = asyncio.ensure_future(self._events.__anext__())
        closed_by_client_task = asyncio.ensure_future(self._closed_by_client.wait())
        try:
            await asyncio.wait(
                {next_event_task, closed_by_client_task},
                return_when=asyncio.FIRST_COMPLETED,
            )
        except BaseException:
            next_event_task.cancel()
            raise
        finally:
            closed_by_client_task.cancel()

        if self._closed_by_client.is_set():
            next_event_task.cancel()
            await asyncio.gather(next_event_task, return_exceptions=True)
            await self._finish(SseStreamEndReason.CLOSED_BY_CLIENT)
            raise StopAsyncIteration

        try:
            return next_event_task.result()
        except StopAsyncIteration:
            await self._finish(SseStreamEndReason.CLOSED)
        except httpx2.ReadTimeout:
            await self._finish(SseStreamEndReason.IDLE_TIMEOUT)
        except Exception:
            await self._finish(SseStreamEndReason.ERROR)
        raise StopAsyncIteration

    async def _read_events_from_response(self) -> AsyncIterator[SseEvent]:
        # SSE framing is parsed per the WHATWG SSE standard by httpx2's EventSource
        # (https://html.spec.whatwg.org/multipage/server-sent-events.html): comment lines
        # (starting with ":") are not events. The read timeout is the idle timeout, so any
        # bytes received, a comment line included, reset it.
        async for server_sent_event in httpx2.EventSource(self._response):
            yield SseEvent(event_name=server_sent_event.event, data=server_sent_event.data)

    async def _finish(self, end_reason: SseStreamEndReason) -> None:
        if self.end_reason is not None:
            return
        self.end_reason = end_reason
        try:
            await self._response.aclose()
            await self._http_client.aclose()
        finally:
            self._finished.set()


class HttpSseClient:
    def __init__(self, ssl_context: ssl.SSLContext | None = None) -> None:
        """``ssl_context`` verifies HTTPS servers; default: the SDK RPC control server's
        pinned certificate."""
        self._ssl_context = (
            ssl_context
            if ssl_context is not None
            else pinned_certificate_ssl_context(sdk_rpc_server_certificate_pem())
        )

    async def post(
        self,
        url: str,
        headers: dict[str, str],
        body: bytes,
        content_type: str,
        idle_timeout: float | None,
    ) -> HttpReply | HttpSseStream:
        """POST ``body`` to ``url``. Returns the reply, or an ``HttpSseStream`` when the reply
        is ``text/event-stream``. ``idle_timeout`` is the longest wait, in seconds, for any
        bytes from the server (``None`` waits forever). Transport failures before a reply
        arrives raise ``httpx2.HTTPError``; a URL that is not ``https://`` raises
        ``httpx2.UnsupportedProtocol`` before anything is sent."""
        if httpx2.URL(url).scheme != "https":
            raise httpx2.UnsupportedProtocol(f"only https:// endpoints are supported, not {url}")
        http_client = httpx2.AsyncClient(timeout=httpx2.Timeout(idle_timeout), verify=self._ssl_context)
        request_headers = dict(headers)
        request_headers["Content-Type"] = content_type
        try:
            request = http_client.build_request("POST", url, headers=request_headers, content=body)
            response = await http_client.send(request, stream=True)
        except BaseException:
            await http_client.aclose()
            raise

        if reply_is_event_stream(response):
            return HttpSseStream(http_client, response)

        try:
            reply_body = await response.aread()
            return HttpReply(status=response.status_code, headers=dict(response.headers), body=reply_body)
        finally:
            await response.aclose()
            await http_client.aclose()

    async def get(self, url: str, timeout: float | None) -> HttpReply:
        """GET ``url`` with no credentials, verified by the same pinned certificate as ``post``.
        Transport failures raise ``httpx2.HTTPError``; a URL that is not ``https://`` raises
        ``httpx2.UnsupportedProtocol`` before anything is sent."""
        if httpx2.URL(url).scheme != "https":
            raise httpx2.UnsupportedProtocol(f"only https:// endpoints are supported, not {url}")
        async with httpx2.AsyncClient(timeout=httpx2.Timeout(timeout), verify=self._ssl_context) as http_client:
            response = await http_client.get(url)
            return HttpReply(status=response.status_code, headers=dict(response.headers), body=response.content)

    async def close_stream(self, stream: HttpSseStream) -> None:
        await stream.close_from_client()
